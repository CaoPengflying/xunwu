package com.mclon.kernel.support.stock.provider;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mclon.facade.service.api.utils.ModelTransformUtils;

import com.mclon.kernel.support.stock.handle.CssTestImportHandle;
import com.mclon.facade.service.api.framework.BusinessException;
import com.mclon.facade.service.api.common.BasePlusProviderImpl;
import com.mclon.facade.service.api.stock.CssTestImportProvider;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;
import com.mclon.facade.service.api.stock.model.CssTestImport;
import com.mclon.kernel.support.stock.service.CssTestImportService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.assertj.core.util.Lists;

import java.util.List;

import tk.mybatis.mapper.entity.Example;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;

import java.util.Map;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
@Service
public class CssTestImportProviderImpl extends BasePlusProviderImpl<ExtCssTestImport> implements CssTestImportProvider {

    /**
     * 日志
     */
    private static final Logger logger = LoggerFactory.getLogger(CssTestImportProviderImpl.class);

    @Resource
    private CssTestImportService cssTestImportService;

    /**
     * 标准新增
     * 1、校验入参
     * 2、执行保存方法
     *
     * @param extCssTestImport ExtCssTestImport
     * @return
     */
    @Override
    public ExtCssTestImport create(ExtCssTestImport extCssTestImport) {
        try {
            // 1、校验入参
            String errorMsg = CssTestImportHandle.checkCreate(extCssTestImport);
            if (StringUtils.isNotEmpty(errorMsg)) {
                throw new BusinessException(errorMsg.toString());
            }
            // 2、执行保存方法
            return cssTestImportService.create(extCssTestImport);
        } catch (Exception e) {
            return super.handleException("测试保存失败！", e);
        }
    }


    /**
     * 标准删除
     * 1、校验入参
     * 2、执行删除方法
     *
     * @param extCssTestImport ExtCssTestImport
     * @return
     */
    @Override
    public ExtCssTestImport delete(ExtCssTestImport extCssTestImport) {
        try {
            // 1、校验入参
            String errorMsg = CssTestImportHandle.checkDelete(extCssTestImport);
            if (StringUtils.isNotEmpty(errorMsg)) {
                throw new BusinessException(errorMsg.toString());
            }
            // 2、执行删除方法
            return cssTestImportService.delete(extCssTestImport);
        } catch (Exception e) {
            return super.handleException("测试删除失败！", e);
        }
    }

    /**
     * 标准修改
     * 1、校验入参
     * 2、执行修改方法
     *
     * @param extCssTestImport ExtCssTestImport
     * @return
     */
    @Override
    public ExtCssTestImport update(ExtCssTestImport extCssTestImport) {
        try {
            // 1、校验入参
            String errorMsg = CssTestImportHandle.checkUpdate(extCssTestImport);
            if (StringUtils.isNotEmpty(errorMsg)) {
                throw new BusinessException(errorMsg.toString());
            }
            // 2、执行修改方法
            return cssTestImportService.update(extCssTestImport);
        } catch (Exception e) {
            return super.handleException("测试修改失败！", e);
        }
    }

    /**
     * 标准详情
     * 1、校验入参
     * 2、执行获取详情
     *
     * @param extCssTestImport ExtCssTestImport
     * @return
     */
    @Override
    public ExtCssTestImport get(ExtCssTestImport extCssTestImport) {
        try {
            // 1、校验入参
            String errorMsg = CssTestImportHandle.checkGet(extCssTestImport);
            if (StringUtils.isNotEmpty(errorMsg)) {
                throw new BusinessException(errorMsg.toString());
            }
            // 2、执行获取详情方法
            return cssTestImportService.get(extCssTestImport);
        } catch (Exception e) {
            return super.handleException("测试获取详情失败！", e);
        }
    }

    /**
     * 标准详情
     * 1. 执行获取列表
     *
     * @param extCssTestImport
     * @return
     */
    @Override
    public List<ExtCssTestImport> listByCondition(ExtCssTestImport extCssTestImport) {
        try {
            QueryWrapper<CssTestImport> queryWrapper = new QueryWrapper<>();
            List<CssTestImport> list = cssTestImportService.list(queryWrapper);
            return ModelTransformUtils.exchangeClassList(list, ExtCssTestImport.class);
        } catch (Exception e) {
            return Lists.newArrayList(super.handleException("测试自定义条件获取列表失败！", e));
        }
    }
}
