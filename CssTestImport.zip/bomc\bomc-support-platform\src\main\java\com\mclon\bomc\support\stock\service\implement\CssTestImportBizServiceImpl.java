package com.mclon.bomc.support.stock.service.implement;

import com.mclon.bomc.support.stock.service.CssTestImportBizService;
import com.mclon.commons.support.webmvc.result.Result;
import com.mclon.commons.support.webmvc.constants.ErrorConstant;
import com.mclon.facade.service.api.stock.StockProviderCenter;
import com.mclon.facade.service.api.stock.CssTestImportProvider;
import com.mclon.commons.support.webmvc.export.ImportResolve;
import org.apache.dubbo.config.annotation.Reference;
import com.mclon.facade.service.api.common.BaseBizServiceImpl;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
@Service("cssTestImportBizService")
public class CssTestImportBizServiceImpl extends BaseBizServiceImpl<ExtCssTestImport> implements CssTestImportBizService {

    /**
     * 日志
     */
    private static final Logger logger = LoggerFactory.getLogger(CssTestImportBizServiceImpl.class);

    @Reference
    private CssTestImportProvider cssTestImportProvider;

    @Resource
    private ImportResolve importResolve;

    /**
     * 标准新增
     * 1、执行保存方法
     *
     * @param object ExtCssTestImport
     * @return
     */
    @Override
    public Result<ExtCssTestImport> create(Object object) {
        try {
            // 1、执行保存方法
            ExtCssTestImport extCssTestImport = (ExtCssTestImport) object;
            return ErrorConstant.getSuccessResult(cssTestImportProvider.create(extCssTestImport),"保存成功");
        } catch (Exception e) {
            return super.handleException("测试保存失败!", StockProviderCenter.descMap, StockProviderCenter.StockProviderEnum.CSSTESTIMPORTPROVIDER.getCode(), e);
        }
    }

    /**
     * 标准删除
     * 1、执行删除方法
     *
     * @param object ExtCssTestImport
     * @return
     */
    @Override
    public Result<ExtCssTestImport> delete(Object object) {
        try {
            // 1、执行删除方法
            ExtCssTestImport extCssTestImport = (ExtCssTestImport) object;
            return ErrorConstant.getSuccessResult(cssTestImportProvider.delete(extCssTestImport),"删除成功");
        } catch (Exception e) {
            return super.handleException("测试删除失败!", StockProviderCenter.descMap, StockProviderCenter.StockProviderEnum.CSSTESTIMPORTPROVIDER.getCode(), e);
        }
    }

    /**
     * 标准修改
     * 1、执行修改方法
     *
     * @param object ExtCssTestImport
     * @return
     */
    @Override
    public Result<ExtCssTestImport> update(Object object) {
        try {
            //1、执行修改方法
            ExtCssTestImport extCssTestImport = (ExtCssTestImport) object;
            return ErrorConstant.getSuccessResult(cssTestImportProvider.update(extCssTestImport),"修改成功");
        } catch (Exception e) {
            return super.handleException("测试修改失败!", StockProviderCenter.descMap, StockProviderCenter.StockProviderEnum.CSSTESTIMPORTPROVIDER.getCode(), e);
        }
    }

    /**
     * 标准获取详情
     *
     * @param object ExtCssTestImport
     * @return
     */
    @Override
    public Result get(Object object) {
        try {
            ExtCssTestImport extCssTestImport = (ExtCssTestImport) object;
            return ErrorConstant.getSuccessResult(cssTestImportProvider.get(extCssTestImport),"获取详情成功");
        } catch (Exception e) {
            return super.handleException("测试获取详情!", StockProviderCenter.descMap, StockProviderCenter.StockProviderEnum.CSSTESTIMPORTPROVIDER.getCode(), e);
        }
    }

}
