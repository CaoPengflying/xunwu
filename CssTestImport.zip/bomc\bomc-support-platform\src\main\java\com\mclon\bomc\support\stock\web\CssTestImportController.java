package com.mclon.bomc.support.stock.web;

import com.mclon.commons.support.webmvc.constants.ErrorConstant;
import com.aliyun.oss.model.ObjectMetadata;

import com.mclon.commons.support.webmvc.constants.ApplicationConstants;
import org.apache.commons.lang3.StringUtils;
import com.mclon.facade.service.api.common.BaseModel;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectResult;
import org.springframework.beans.factory.annotation.Value;
import com.mclon.commons.support.webmvc.export.ExportResolve;
import com.mclon.facade.service.api.stock.constants.CssTestImportConstants;
import com.mclon.bomc.support.stock.service.CssTestImportBizService;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;
import com.mclon.bomc.cloud.framework.annotation.QineasyGuest;
import com.mclon.bomc.cloud.framework.annotation.QineasyService;
import com.mclon.commons.support.webmvc.constants.HeadersConstant;
import com.mclon.commons.support.webmvc.result.Result;
import com.mclon.facade.service.api.utils.GetInfo;
import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.web.multipart.MultipartHttpServletRequest;
import com.mclon.commons.support.lang.convention.DateUtils;

import io.swagger.annotations.ApiParam;
import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import com.aliyun.oss.model.PutObjectRequest;


import java.util.Iterator;
import java.util.UUID;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
@QineasyService
@RequestMapping(value = "cssTestImport", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CssTestImportController {

    private static final Logger logger = LoggerFactory.getLogger(CssTestImportController.class);


    @Resource
    private CssTestImportBizService cssTestImportBizService;

    /**
     * Reason: 新增测试(单表)
     */
    @QineasyGuest
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public Result create(
            @RequestParam(value = "jsonObject") String jsonObject,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_ID) String userId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_NAME) String userName,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_ID) String organizationId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_NAME) String organizationName) throws Exception {
        //转JSON对象
        ExtCssTestImport extCssTestImport = GetInfo.parseJSON(ExtCssTestImport.class, jsonObject);
        GetInfo.stringToJsonString(Lists.newArrayList(extCssTestImport), ExtCssTestImport.class,
                CssTestImportConstants.MAIN_ID_STR, userId, userName, organizationId, organizationName);
        return cssTestImportBizService.create(extCssTestImport);
    }


    /**
     * Reason: 删除测试
     */
    @QineasyGuest
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public Result delete(
            @ApiParam(value = "jsonObject:{idList:[1,2]}") @RequestParam(value = "jsonObject") String jsonObject,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_ID) String userId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_NAME) String userName,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_ID) String organizationId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_NAME) String organizationName) {
        ExtCssTestImport extCssTestImport = GetInfo.parseJSON(ExtCssTestImport.class, jsonObject);
        return cssTestImportBizService.delete(extCssTestImport);
    }

    /**
     * Reason: 修改测试(单表)
     */
    @QineasyGuest
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public Result update(
            @RequestParam(value = "jsonObject") String jsonObject,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_ID) String userId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_NAME) String userName,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_ID) String organizationId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_NAME) String organizationName
    ) throws Exception {
        ExtCssTestImport extCssTestImport = GetInfo.parseJSON(ExtCssTestImport.class, jsonObject);
        GetInfo.stringToJsonString(Lists.newArrayList(extCssTestImport), ExtCssTestImport.class,
                CssTestImportConstants.MAIN_ID_STR, userId, userName, organizationId, organizationName);
        return cssTestImportBizService.update(extCssTestImport);
    }


    /**
     * Reason: 获取详情
     */
    @QineasyGuest
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public Result get(
            @RequestParam(value = "jsonObject") String jsonObject,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_ID) String userId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_USER_NAME) String userName,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_ID) String organizationId,
            @RequestHeader(name = HeadersConstant.X_OAUTH_ORGANIZATION_NAME) String organizationName
    ) {
        ExtCssTestImport extCssTestImport = GetInfo.parseJSON(ExtCssTestImport.class, jsonObject);
        return cssTestImportBizService.get(extCssTestImport);
    }

}
