package com.mclon.kernel.support.stock.service.implement;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mclon.facade.service.api.framework.BusinessException;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;
import com.mclon.facade.service.api.stock.model.CssTestImport;
import com.mclon.kernel.support.stock.mapper.CssTestImportMapper;
import com.mclon.kernel.support.stock.service.CssTestImportService;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mclon.commons.support.webmvc.constants.ErrorConstant;
import com.mclon.facade.service.api.common.BasePlusServiceImpl;
import org.springframework.transaction.annotation.Transactional;


import javax.annotation.Resource;

import com.mclon.facade.service.api.utils.ModelTransformUtils;

import java.util.List;
import java.util.Map;

/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
@Service
public class CssTestImportServiceImpl extends BasePlusServiceImpl<CssTestImportMapper, CssTestImport, ExtCssTestImport> implements CssTestImportService {
    /**
     * 日志
     */
    private static final Logger logger = LoggerFactory.getLogger(CssTestImportServiceImpl.class);

    @Resource
    private CssTestImportMapper cssTestImportMapper;

    /**
     * 标准新增
     * 1、执行保存方法
     *
     * @param extCssTestImport
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExtCssTestImport create(ExtCssTestImport extCssTestImport) {
        // 1、执行保存方法
        boolean saveFlag = this.save(extCssTestImport);
        if (saveFlag){
            return extCssTestImport;
        }else {
            return null;
        }
    }


    /**
     * 标准删除
     * 1、执行删除方法
     *
     * @param extCssTestImport
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExtCssTestImport delete(ExtCssTestImport extCssTestImport) {
        QueryWrapper<CssTestImport> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().in(CssTestImport::getCssTestImportId, extCssTestImport.getIdList());
        Integer count = cssTestImportMapper.selectCount(queryWrapper);
        if (count != extCssTestImport.getIdList().size()){
            throw new BusinessException("数据已被更新，请刷新！", ErrorConstant.DATA_NOT_EXISTS);
        }
        boolean removeFlag = this.removeByIds(extCssTestImport.getIdList());
        if (removeFlag){
            return extCssTestImport;
        }else {
            throw new BusinessException("删除失败！", ErrorConstant.FAIL);
        }
    }

    /**
     * 标准修改
     * 1、执行修改方法
     *
     * @param extCssTestImport
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExtCssTestImport update(ExtCssTestImport extCssTestImport) {
        CssTestImport cssTestImport = this.getById(extCssTestImport.getCssTestImportId());
        if (null == cssTestImport) {
            return null;
        }
        boolean updateFlag = this.updateById(extCssTestImport);
        if (updateFlag){
            return extCssTestImport;
        }else {
            throw new BusinessException("修改失败！", ErrorConstant.FAIL);
        }
    }

    /**
     * 标准详情
     *
     * @param extCssTestImport
     * @return
     */
    @Override
    public ExtCssTestImport get(ExtCssTestImport extCssTestImport) {
        CssTestImport cssTestImport = this.getById(extCssTestImport.getCssTestImportId());
        if (null == cssTestImport) {
            throw new BusinessException("数据已被更新，请刷新！", ErrorConstant.DATA_NOT_EXISTS);
        }
        return ModelTransformUtils.exchangeClass(cssTestImport, ExtCssTestImport.class);
    }

}
