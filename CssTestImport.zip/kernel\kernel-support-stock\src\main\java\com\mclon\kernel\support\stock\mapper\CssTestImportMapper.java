package com.mclon.kernel.support.stock.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mclon.facade.service.api.stock.model.CssTestImport;
import com.mclon.kernel.support.stock.repository.MyBatisRepository;

/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试 mapper
 * @date Created in 2020-02-01
 */
@MyBatisRepository
public interface CssTestImportMapper extends BaseMapper<CssTestImport> {

}
