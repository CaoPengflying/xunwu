package com.mclon.kernel.support.stock.handle;

import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;

import java.util.List;
import java.util.Map;
import com.mclon.commons.support.lang.convention.IntegerUtils;

import com.mclon.facade.service.api.common.BaseModel;

import com.mclon.commons.support.webmvc.constants.ErrorConstant;
import com.mclon.commons.support.webmvc.result.Result;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.compress.utils.Lists;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试 Service扩展
 * @date Created in 2020-02-01
 */

public class CssTestImportHandle {

    /**
     * 校验测试主表新增
     *
     * @return
     */
    public static String checkCreate(ExtCssTestImport extCssTestImport) {
        StringBuilder errorMsg = new StringBuilder();
        /*if (condition){
            errorMsg.append("错误提示");
        }*/
       return errorMsg.toString();
    }

    /**
     * 校验测试主表删除
     *
     * @return
     */
    public static String checkDelete(ExtCssTestImport extCssTestImport) {
        StringBuilder errorMsg = new StringBuilder();
        if (CollectionUtils.isEmpty(extCssTestImport.getIdList())) {
            errorMsg.append("idList标识不能为空");
        }
       return errorMsg.toString();
    }

    /**
     * 校验测试主表更新
     *
     * @return
     */
    public static String checkUpdate(ExtCssTestImport extCssTestImport) {
        StringBuilder errorMsg = new StringBuilder();
        if (IntegerUtils.isEmpty(extCssTestImport.getCssTestImportId())){
            errorMsg.append("id标识不能为空");
        }
       return errorMsg.toString();
    }

    /**
     * 校验测试主表获取详情
     *
     * @return
     */
    public static String checkGet(ExtCssTestImport extCssTestImport) {
        StringBuilder errorMsg = new StringBuilder();
        if (null == extCssTestImport.getCssTestImportId()) {
            errorMsg.append("id标识不能为空");
        }
        return errorMsg.toString();
    }


}
