package com.mclon.kernel.support.stock.service;

import com.mclon.facade.service.api.common.BasePlusService;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;
import com.mclon.facade.service.api.stock.model.CssTestImport;
import com.mclon.commons.support.webmvc.result.Result;

import java.util.List;
import tk.mybatis.mapper.entity.Example;

/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
public interface CssTestImportService extends BasePlusService<ExtCssTestImport,CssTestImport> {
}
