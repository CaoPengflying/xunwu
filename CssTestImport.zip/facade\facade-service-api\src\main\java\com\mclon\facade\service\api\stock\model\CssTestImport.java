package  com.mclon.facade.service.api.stock.model;

import com.baomidou.mybatisplus.annotation.IdType;
import lombok.*;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
@TableName(value = "css_test_import")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CssTestImport implements Serializable {
	/**
	 * 现有量ID
	 */
	@TableField("goods_id")
	private Integer goodsId;
	/**
	 * 主石重
	 */
	@TableField("stone_weight")
	private BigDecimal stoneWeight;

}
