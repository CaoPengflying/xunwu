package com.mclon.facade.service.api.stock;

import com.mclon.facade.service.api.common.BasePlusProvider;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;

import java.util.List;
import tk.mybatis.mapper.entity.Example;
import com.mclon.commons.support.webmvc.result.Result;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
public interface CssTestImportProvider extends BasePlusProvider<ExtCssTestImport> {
}
