package com.mclon.facade.service.api.stock.constants;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试 常量
 * @date Created in 2020-02-01
 */
public interface CssTestImportConstants {
    /**
     * 描述
     */
    String  DESC = "测试";
    /**
     * 主键id名
     */
    String MAIN_ID_STR = "CssTestImportId";
    /**
     * 单据类型
     */
    String RECEIPT_TYPE = "";
    /**
     * guid
     */
    String GUID = "";

}

