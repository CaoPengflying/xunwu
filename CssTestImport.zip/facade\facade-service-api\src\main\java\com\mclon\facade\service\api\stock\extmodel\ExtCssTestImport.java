package com.mclon.facade.service.api.stock.extmodel;

import com.mclon.facade.service.api.stock.model.CssTestImport;

import java.util.List;

import lombok.*;

/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试 扩展类
 * @date Created in 2020-02-01
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ExtCssTestImport extends CssTestImport {
    private List<Integer> idList;
    /**
     * 导入错误错误信息
     */
    private String importErrorMsg;

}
