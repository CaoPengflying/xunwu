package com.mclon.bomc.support.stock.service;

import com.mclon.facade.service.api.common.BaseBizService;
import com.mclon.facade.service.api.stock.extmodel.ExtCssTestImport;


/**
 * @author caopengflying
 * @version web 1.0.0
 * @description 测试
 * @date Created in 2020-02-01
 */
public interface CssTestImportBizService extends BaseBizService<ExtCssTestImport> {

}
