package  com.mclon.facade.service.api.product.model;

import com.baomidou.mybatisplus.annotation.IdType;
import lombok.*;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@TableName(value = "product_price")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ProductPrice implements Serializable {
	/**
	 * 记录标识
	 */
	@TableId(value = "product_price_id", type = IdType.AUTO)
	private Integer productPriceId;
	/**
	 * 款式id
	 */
	@TableField("product_model_id")
	private Integer productModelId;
	/**
	 * SKU记录标识
	 */
	@TableField("product_id")
	private Integer productId;
	/**
	 * 档级
	 */
	@TableField("grade")
	private String grade;
	/**
	 * 主石重量
	 */
	@TableField("stone_weight")
	private BigDecimal stoneWeight;
	/**
	 * 物料大类标识
	 */
	@TableField("class_id")
	private Integer classId;
	/**
	 * 前一次价格段始
	 */
	@TableField("last_price_min")
	private BigDecimal lastPriceMin;
	/**
	 * 前一次价格段止
	 */
	@TableField("last_price_max")
	private BigDecimal lastPriceMax;
	/**
	 * 当前成品价格段始
	 */
	@TableField("price_min")
	private BigDecimal priceMin;
	/**
	 * 当前成品价格段止
	 */
	@TableField("price_max")
	private BigDecimal priceMax;
	/**
	 * 数据状态-1封存，0正常1已经激活使用
	 */
	@TableField("status")
	private Integer status;
	/**
	 * 业务备注
	 */
	@TableField("memo")
	private String memo;
	/**
	 * 数据备注
	 */
	@TableField("remark")
	private String remark;
	/**
	 * 创建人
	 */
	@TableField("create_user")
	private Integer createUser;
	@TableField("organization_id_create")
	private Integer organizationIdCreate;
	/**
	 * 创建时间
	 */
	@TableField("create_time")
	private Date createTime;
	/**
	 * 最后修改人
	 */
	@TableField("update_user")
	private Integer updateUser;
	/**
	 * 最后修改时间
	 */
	@TableField("update_time")
	private Date updateTime;
	/**
	 * 执行信息描述
	 */
	@TableField("calc_memo")
	private String calcMemo;

}
